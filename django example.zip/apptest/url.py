from django.urls import path
from apptest import views as testview

app_name = 'apptest'

urlpatterns = [
    path('qwer/', testview.qwer, name='qwer'),
    path('asdf/', testview.asdf, name='asdf'),
]