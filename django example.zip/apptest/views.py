from django.shortcuts import render

# Create your views here.
def test(request):
    temp =  {
        'qwer':'하하하',
        'asdf':'호호호',
    }
    return render(request,'test.html', {'q':temp})

def qwer(request):
    return render(request,'apptest/qwer.html')

def asdf(request):
    return render(request,'apptest/asdf.html')