from django.urls import path
from pages import views as pageview

app_name = 'pages'

urlpatterns = [
    path('zxcv/', pageview.zxcv)
]