from django.shortcuts import render
from django.core import serializers
from django.http import JsonResponse
from .models import DepositOptions, DepositProducts
from .serializers import DepositProductsSerializer, DepositOptionsSerializer
import requests
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.db.models import Max 
from rest_framework import status
from django.conf import settings
# Create your views here.

@api_view(['GET'])
def save_deposit_products(request):
    auth_key = settings.API_KEY
    fin_grp_no = '020000'
    page_no = '1'
    base_url = f'http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json?auth={auth_key}&topFinGrpNo={fin_grp_no}&pageNo={page_no}'
    response = requests.get(base_url)
    results = response.json()

    result = results['result']['baseList']
    serializer = DepositProductsSerializer(data=result, many=True)
    if serializer.is_valid():
        serializer.save()
    else:
        Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    for result in results['result']['optionList']:
        serializer = DepositOptionsSerializer(data=result)
        if serializer.is_valid():
            temp = serializer.save(fin_prdt_cd=DepositProducts.objects.get(fin_prdt_cd=result['fin_prdt_cd']))
            temp.save()
        else:
            Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    return Response('message : okay')


@api_view(['GET','POST'])
def deposit_products(request):
    if request.method == 'GET':
        products = DepositProducts.objects.all()
        serializer = DepositProductsSerializer(products, many=True)
        return Response(serializer.data)
    
    if request.method == 'POST':
        serializer = DepositProductsSerializer(data=request.POST)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def deposit_product_options(request, fin_prdt_cd):
    temp = DepositProducts.objects.get(fin_prdt_cd=fin_prdt_cd)
    deposit_options = DepositOptions.objects.filter(fin_prdt_cd=temp.id)
    serializer = DepositOptionsSerializer(deposit_options, many=True)
    return Response(serializer.data)
    

@api_view(['GET'])
def top_rate(request):
    max_val = DepositOptions.objects.aggregate(
        intr_rate2=Max('intr_rate2'), 
        fin_prdt_cd_id=Max('fin_prdt_cd_id')
    )
    temp = DepositProducts.objects.get(pk=max_val['fin_prdt_cd_id'])
    serializer = DepositProductsSerializer(temp)
    return Response(serializer.data)