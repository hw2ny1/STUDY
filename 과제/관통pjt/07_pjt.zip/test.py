import requests
from pprint import pprint

response = requests.get('http://finlife.fss.or.kr/finlifeapi/depositProductsSearch.json?auth=401dd588ce6654ecff5096113714cf49&topFinGrpNo=020000&pageNo=1')
result = response.json()

pprint(result)