<template>
  <div>
    <router-link
      :to="{
        name: 'detailview',
        params: { id:searchresult}
      }">
    <div class="card" style="width: 18rem;">
      <img :src="searchresult.snippet.thumbnails.high.url" class="card-img-top" alt="">
      <div class="card-body">
        <p class="card-text">{{searchresult.snippet.title}}</p>
      </div>
    </div>
    </router-link>
  </div>
</template>

<script>
export default {
  name: 'SearchVideoList',
  props: {
    searchresult:Object
  }
}
</script>
