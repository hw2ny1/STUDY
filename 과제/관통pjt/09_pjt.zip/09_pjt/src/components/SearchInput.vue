<template>
  <div class="searchinput">
    <div class="input-group mb-3">
    <input type="text" class="form-control" placeholder="검색어를 입력하세요" aria-label="serch" aria-describedby="button-addon2" @keyup.enter="search" v-model="inputText" id="inputText">
    <button class="btn btn-outline-secondary" type="button" id="button-addon2" @click="search">찾기</button>
  </div>
</div>
</template>

<script>
export default {
  name: 'SearchInput',
  data() {
    return {
      inputText : null
    }
  },
  methods: {
    search() {
      const searchText = this.inputText.trim()
      if (!searchText) {
        alert('검색어를 입력해주세요')
        return
      } else {
        this.$emit('search-text', searchText)
        this.inputText = null;
      }
    },
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
