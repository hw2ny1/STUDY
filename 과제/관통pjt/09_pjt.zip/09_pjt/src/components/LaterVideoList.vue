<template>
  <div class="laterview">
    <router-link
      :to="{
        name: 'homeview',
      }">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
      <div><span class="material-symbols-outlined">arrow_back</span>뒤로가기</div>
    </router-link>
    <h1>나중에 볼 영상</h1>
    <div class="d-flex align-content-stretch flex-wrap">
      <LaterView
      v-for="laterresult in $store.getters.lateListResult"
      :laterresult="laterresult"
      :key="laterresult.id.videoId"/>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import LaterVideoList from '@/components/LaterVideoList.vue'
import LaterView from '@/views/LaterView.vue';

export default {
  name: 'LaterList',
  components: {
    LaterVideoList,
    LaterView
},
  methods: {
  }
}
</script>
