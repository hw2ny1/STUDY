<template>
  <div class="detailview">
    <router-link
      :to="{
        name: 'searchview',
      }">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
      <div><span class="material-symbols-outlined">arrow_back</span>뒤로가기</div>
    </router-link>
    <h1>{{$route.params.id.snippet.title}}</h1>
    <p>업로드 날짜 : {{ $route.params.id.snippet.publishTime }}</p>
    <div>
    <iframe
      width="560"
      height="315"
      :src="`https://www.youtube.com/embed/${$route.params.id.id.kind}`"
      frameborder="0"
      allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
      allowfullscreen
      ></iframe>
    </div>
    <p>{{$route.params.id.snippet.description}}</p>
    <button @click="videosave" type="button" class="btn btn-primary">동영상 저장</button>
  </div>
</template>



<script>
export default {
  name: 'DetailView',
  props: {
    searchresult:Object
  },
  methods:{
    videosave : function(){
      console.log('zzzz')
      this.$store.commit('LATERLIST', this.searchresult)
    }
  }
}
</script>