<template>
  <div class="searchview">
    <router-link
      :to="{
        name: 'homeview',
      }">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
      <div><span class="material-symbols-outlined">arrow_back</span>뒤로가기</div>
    </router-link>
    <h1>비디오 검색</h1>
    <SearchInput
    @search-text="getSearch"/>
    <div class="d-flex align-content-stretch flex-wrap">
      <SearchVideoList
      v-for="searchresult in $store.getters.getSearchResult"
      :searchresult="searchresult"
      :key="searchresult.id.videoId"/>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import SearchInput from '@/components/SearchInput.vue'
import SearchVideoList from '@/components/SearchVideoList.vue'
import axios from 'axios'

const API_URL = 'AIzaSyD2eFaqeUj3PDLU7UOdWLmB9eFoBet_n-o'

export default {
  name: 'SearchView',
  components: {
    SearchInput,
    SearchVideoList,
  },
  methods: {
    async getSearch(data) {
      console.log('확인')
      const searchQuery = data
      const response = await axios.get(`https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=24&q=${searchQuery}&type=video&key=${API_URL}`)
      console.log(response.data.items)
      this.$store.commit('SET_SEARCH_RESULT', response.data.items )
    },
  }
}
</script>