<template>
  <div v-if="laterresult">
    <router-link
      :to="{
        name: 'detailview',
        params: { id: laterresult }
      }">
      <div class="card" style="width: 18rem;">
        <img :src="laterresult.snippet.thumbnails.high.url" class="card-img-top" alt="">
        <div class="card-body">
          <p class="card-text">{{ laterresult.snippet.title }}</p>
        </div>
      </div>
    </router-link>
  </div>
  <div v-else>
    <p>등록된 비디오 없음</p>
  </div>
</template>

<script>
export default {
  name: 'LaterVideoList',
  props: {
    laterresult: Object
  }
}
</script>
