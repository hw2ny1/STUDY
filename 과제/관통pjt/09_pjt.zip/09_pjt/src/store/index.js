import Vue from 'vue'
import Vuex from 'vuex'


Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    searchResult: null,
    laterList: [],
  },
  mutations: {
    SET_SEARCH_RESULT(state, searchResult) {
      state.searchResult = searchResult
    },
    LATERLIST(state, laterItem) {
      state.laterList.push(laterItem)
      console.log(state.laterList)
    }
  },
  getters: {
    getSearchResult(state) {
      return state.searchResult
    },
    lateListResult(state) {
      return state.laterList
    }
  }
})
