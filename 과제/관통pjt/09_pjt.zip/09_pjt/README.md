프로젝트 목표
• YouTube API 를 활용한 스트리밍 플랫폼 구현
• AJAX 통신과 JSON 구조에 대한 이해
• Vue CLI, Vue Router, Vuex 플러그인 활용

동영상 검색결과 출력
동영상 상세 정보 출력
나중에 볼 동영상 저장 및 삭제

그 동안 배웠던 vuex와 라우팅 axio를 사용하여 youtube 데이터를 가져와서 활용하는 프로젝트를 하였다.