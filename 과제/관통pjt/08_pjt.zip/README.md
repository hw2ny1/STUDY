numpy와 pandas를 이용하여 csv 파일을 불러왔고 내가 작성한 알고리즘의 성능을 locust로 테스트 해보았다.

나는 평균값과 가까운 10명을 뽑기위해서 나이의 평균값을 구하고 편차를 heap배열에 넣었다.
그래서 편차가 작은 사람부터 10명을 뽑아내었고 이 알고리즘은 10000명의 접속자에서 RPS 170정도를 유지 하였다. 그러나 16000명의 접속자를 넘기자 fail이 많이 발생하였다.

Method	Name	# Requests	# Fails	Average (ms)	Min (ms)	Max (ms)	Average size (bytes)	RPS	Failures/s
GET	/test/find_average_age/	133376	59436	30917	0	110467	978	290.0	129.2
Aggregated	133376	59436	30917	0	110467	978	290.0	129.2