from django.http import JsonResponse
from rest_framework.decorators import api_view
import random

array_length = 1000
random_range = 5000


# @api_view(['GET'])
# def bubble_sort(request):
#     li = []
#     for i in range(array_length):
#         li.append(random.choice(range(1, random_range)))
#     for i in range(len(li) - 1, 0, -1):
#         for j in range(i):
#             if li[j] < li[j + 1]:
#                 li[j], li[j + 1] = li[j + 1], li[j]
#     context = {
#       'top': li[0]
#     }
#     return JsonResponse(context)

# @api_view(['GET'])
# def normal_sort(request):
#     li = []
#     for i in range(array_length):
#         li.append(random.choice(range(1, random_range)))
#     li.sort(reverse=True)
#     context = {
#         'top': li[0]
#     }
#     return JsonResponse(context)

# from queue import PriorityQueue

# @api_view(['GET'])
# def priority_queue(request):
    # pq = PriorityQueue()
    # for i in range(array_length):
    #     pq.put(-random.choice(range(1, random_range)))
    # context = {
    #     'top': -pq.get()
    # }
    # return JsonResponse(context)

import csv
import numpy as np
import pandas as pd

def file_open_by_numpy():
    # np.loadtxt(구분자 = ',', 데이터 타입: string)
    np_arr = np.loadtxt('data/test_data.CSV', delimiter=",", encoding='cp949', dtype=str)
    return np_arr

def pull_data():
    arr = file_open_by_numpy()
    columns = arr[0]
    arr = np.delete(arr, 0, 0)
    df = pd.DataFrame(arr, columns=columns)
    
    df.replace('', np.nan, inplace=True)
    df.fillna({"이름": "무명", "나이": "0", "성별": "모름", "직업": "무직", "사는곳": "미정"}, inplace=True)
    df.dropna(inplace=True)

    df = df.astype({"나이":"int"})

    # data = df.to_dict(orient='records')
    return df

from heapq import heappush, heappop

@api_view(['GET'])
def find_average_age(request):
    df = pull_data()

    avg_age = df['나이'].mean()

    ages = df['나이'].tolist()
    temp = []
    for i, j in enumerate(ages):
        heappush(temp,(abs(j-avg_age),i))
    
    rlt = []
    for _ in range(10):
        a,b = heappop(temp)
        rlt.append(b)
    df = df.loc[rlt]
    data = df.to_dict(orient='records')
    return JsonResponse({'dat':data}, safe=False)
