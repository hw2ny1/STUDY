from django.urls import path
from . import views

urlpatterns = [
    # path('normal_sort/', views.normal_sort),
    # path('priority_queue/', views.priority_queue),
    # path('bubble_sort/', views.bubble_sort),
    path('pull_data/', views.pull_data),
    path('find_average_age/', views.find_average_age),
]

