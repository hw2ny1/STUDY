from django.shortcuts import render
from .models import Travels
from .forms import TForm
# Create your views here.
def index(request):
    travels = Travels.objects.all()
    context = {
        'travels':travels
    }
    return render(request,'travels/index.html',context)