from django import forms
from .models import Travels

class TForm(forms.ModelForm):
    
    class Meta:
        model = Travels
        fields = '__all__'
